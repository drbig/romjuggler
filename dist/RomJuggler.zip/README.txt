Rom Juggler

Visit https://github.com/drbig/romjuggler for the most current version and more information.
Edit romjuggler.cfg in any text editor to suit your needs *before you start the program*.

Start by double-clicking RomJuggler.jar, or through command line:
java -jar RomJuggler.jar

If you like it - spread it!

(C) Copyright Piotr S. Staszewski 2013
http://www.drbig.one.pl
<p.staszewski@gmail.com>

This work is licensed under a Creative Commons Attribution-NonCommercial 3.0 Unported License.
Full legal code at http://creativecommons.org/licenses/by-nc/3.0/legalcode
